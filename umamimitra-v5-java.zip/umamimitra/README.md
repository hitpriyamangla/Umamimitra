# UmamiMitra v5: two laptops, 100% Java (IntelliJ IDEA)

No Python, no scripts, no libraries. Only core Java 17+ (`com.sun.net.httpserver`, `java.net.http`, `java.util.zip`).

    PASSENGER LAPTOP                              GALLEY LAPTOP (crew + caterer)
    passenger screens (browser)                   crew + catering screen (browser)
         | http://localhost:3001                       | http://localhost:3000
    3 Passenger Bridge  ====== link (radio) ======>  2 Galley Hub  -->  1 Galley Server (all the logic, AI, allergen checks)

## Open in IntelliJ
1. Install a JDK 17 or newer (IntelliJ can download one: File > Project Structure > SDKs > Add SDK > Download JDK).
2. File > Open > choose this folder (the one with `pom.xml`) > "Open as Project". IntelliJ imports it with Maven (needs internet ONCE, to fetch Maven's own plugins; do this before the flight).
3. The run configurations appear in the top-right dropdown:
   `1 Galley Server`, `2 Galley Hub`, `3 Passenger Bridge`, `Test (one computer, 15% frame loss)`.

## Try it on one computer
Run, in this order (each in its own run window): **1 Galley Server**, **2 Galley Hub**, **3 Passenger Bridge**.
Then open http://localhost:3000 (galley) and http://localhost:3001 (passenger). The green badge top-right on the passenger screens means the link is up.
Or just run **Test (one computer...)**: it starts all three in one program, drops 15% of the frames, and prints PASS/FAIL. `LOSS=0` (run configuration > Environment variables) gives a clean run.

## Two laptops
Copy this whole project folder to both laptops and open it in IntelliJ on each.
1. Link the laptops. Bluetooth way: pair them in the OS, then turn on a Bluetooth Personal Area Network on the galley laptop and join it from the passenger laptop (Windows: "Join a Personal Area Network"; macOS: Bluetooth > Network). Any other link works too (hotspot, cable, Wi-Fi without internet).
2. Galley laptop: find its IP address on that link (`ipconfig` / `ifconfig`). Run **1 Galley Server** then **2 Galley Hub**. Open http://localhost:3000.
3. Passenger laptop: edit the run configuration **3 Passenger Bridge**, set Program arguments to `--hub <galley-ip>` (for example `--hub 192.168.44.1`), run it, open http://localhost:3001.
4. The first time, allow Java through the firewall on the galley laptop (port 7777).

The 3-minute demo script is unchanged: Galley "Reset", passenger types "I'm vegetarian, allergic to peanuts, I prefer paneer", then edit in flight (soy, sesame, kiwi), galley shows the red banner, Acknowledge, Served. The "Hub & AI" page shows frames, CRC checks and AI findings. "Weak signal" on the passenger page shows retries.

Optional AI: set the environment variable `ANTHROPIC_API_KEY` in the Galley Server run configuration. Without it the built-in rules are used.

## How the link works
Same format as before: a call or answer = JSON, zlib compressed, plus a 4-byte CRC32, cut into frames `msg id (2) | frame no (2) | frame count (2) | data`. Frames start at the smallest Bluetooth size (20 bytes), a HELLO frame every 10 s is the heartbeat and tells the hub the largest frame size. The receiver notices a stalled message after 1 s and sends a NACK listing missing frame numbers; the sender repeats only those. After 4 s of silence the whole request is resent; the hub caches answers by message id, so a repeated order is never applied twice. Only `/api/` paths with GET/POST cross the link. The passenger bridge caches identical GETs for 2 s and merges identical calls in flight.

Code map (`src/main/java/com/umamimitra`):
- `galley/` the Java server (`Main`, `MealService`, ...) plus `Hub` (link side + status page on port 3002)
- `passenger/Bridge` the passenger web server and link client
- `link/` `Wire` (framing, CRC, resend), `TunnelServer`, `TunnelClient`, `Radio` (the interface a radio must offer), `TcpRadio`
- Screens: `web/galley`, `web/passenger`

## Honest limits
- **Java cannot talk Bluetooth LE by itself.** Core Java has no Bluetooth API. So the radio in this version is `TcpRadio`: the same small frames over one connection on any link between the laptops, including a Bluetooth PAN. All the protocol, loss handling and screens are the same and tested; only the last hop differs from a raw BLE radio.
- A true BLE radio (no pairing, no IP) would need a third-party Java library (for example SimpleBLE) written against `Radio.Peripheral` / `Radio.Central`. It cannot be tested without two real laptops, so it is not included.
- Tested here: the full flow with 15% dropped frames and 20-byte frames (`E2ETest`). Not tested here: the Maven import in IntelliJ, and a real two-laptop run over a Bluetooth PAN.
- No security: the hub accepts any computer that can reach port 7777 (start the hub with `--local` to allow only this computer), and anyone who knows a login id can edit that passport.
