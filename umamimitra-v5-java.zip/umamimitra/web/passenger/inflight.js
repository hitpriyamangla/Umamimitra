// In-flight edit screen. After "connect", this page talks ONLY to the seat hub over Bluetooth:
//   /api/ble/frame  (send a packet)   /api/ble/read  (read the current meal)
// It never calls /api/meals, /api/parse or /api/expand: all the thinking happens on the server.

// Must match the order in the server (AllergenDb.KEYWORDS) = message format version 1.
const ORDER = ["peanuts","treenuts","dairy","egg","gluten","soy","sesame","fish","shellfish","buckwheat","mustard","coconut"];
const DIET_CODE = { vegetarian: "V", vegan: "G", jain: "J", nonveg: "N" };
const SPICE_CODE = { low: "l", mild: "m", spicy: "s" };
const FRAME_DATA = 16;                       // bytes per frame (BLE default packet is 20 bytes)

let connected = false, transport = null, customAllergies = [], likes = [], busy = false, savedMeat = null;

// ---------- Allergy tick boxes (same names as the passenger page) ----------
document.getElementById("allergy-boxes").innerHTML = ORDER.map(k =>
  `<label class="option"><input type="checkbox" name="allergy" value="${k}"> ${ALLERGEN_NAMES[k]}</label>`).join("");



// A veg diet means no meat at all: beef AND pork are ticked and locked (the server enforces it too).
function syncMeatBoxes() {
  const beef = document.getElementById("noBeef"), pork = document.getElementById("noPork");
  const note = document.getElementById("meat-note");
  if (VEG_DIETS.includes(val("diet"))) {
    if (!savedMeat) savedMeat = { beef: beef.checked, pork: pork.checked };
    beef.checked = pork.checked = true; beef.disabled = pork.disabled = true;
    note.textContent = "Your diet already excludes all meat: beef, pork, chicken and fish.";
  } else {
    beef.disabled = pork.disabled = false;
    if (savedMeat) { beef.checked = savedMeat.beef; pork.checked = savedMeat.pork; savedMeat = null; }
    note.textContent = "";
  }
}
document.querySelectorAll('input[name="diet"]').forEach(r => r.addEventListener("change", syncMeatBoxes));

const val = n => document.querySelector(`input[name="${n}"]:checked`).value;
const sleep = ms => new Promise(r => setTimeout(r, ms));

// ---------- Message building ----------
function crc32(bytes) {
  let c, crc = 0xFFFFFFFF;
  for (const b of bytes) { c = (crc ^ b) & 0xFF; for (let k = 0; k < 8; k++) c = c & 1 ? (c >>> 1) ^ 0xEDB88320 : c >>> 1; crc = (crc >>> 8) ^ c; }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}
const clean = s => s.replace(/[|;\n\r]/g, " ").trim();

function buildPayload() {
  let mask = 0;
  document.querySelectorAll('input[name="allergy"]:checked').forEach(b => { mask |= 1 << ORDER.indexOf(b.value); });
  const flags = (document.getElementById("noBeef").checked ? "B" : "") + (document.getElementById("noPork").checked ? "P" : "")
              + (document.getElementById("severe").checked ? "S" : "");
  // Version 2: UM2 | login id | seat | diet | flags | allergen mask | spice | typed allergies | likes | free text
  return ["UM2", clean(document.getElementById("pid").value).toLowerCase(), document.getElementById("seat").value.trim().toUpperCase(),
          DIET_CODE[val("diet")], flags, mask.toString(16), SPICE_CODE[val("spice")], customAllergies.map(clean).join(";"),
          likes.map(clean).join(";"), clean(document.getElementById("free-text").value).replace(/\|/g, " ")].join("|");
}

function toBytes(payload) {
  const body = new TextEncoder().encode(payload);
  const crc = crc32(body);
  const out = new Uint8Array(body.length + 4);
  out.set(body);
  new DataView(out.buffer).setUint32(body.length, crc);       // big-endian CRC at the end
  return out;
}
const hex = bytes => Array.from(bytes).map(b => b.toString(16).padStart(2, "0")).join("");

// ---------- Transports ----------
// Simulated seat hub: the packet goes to our server, which plays the hub + back end.
const simulated = {
  async sendFrame(m, i, n, chunk) { return api(`/api/ble/frame?m=${m}&i=${i}&n=${n}&d=${hex(chunk)}`, true); },
  async read(seat) { return api("/api/ble/read?seat=" + encodeURIComponent(seat) + "&pid=" + encodeURIComponent(document.getElementById("pid").value.trim().toLowerCase())); }
};

// Real Bluetooth (Web Bluetooth). Needs a seat hub that advertises this GATT service. UNTESTED without hardware.
const SERVICE = "6e5a0001-b5a3-f393-e0a9-e50e24dcca9e";
const WRITE_CHAR = "6e5a0002-b5a3-f393-e0a9-e50e24dcca9e";    // phone -> hub (write without response)
const NOTIFY_CHAR = "6e5a0003-b5a3-f393-e0a9-e50e24dcca9e";   // hub -> phone (reply, UTF-8 JSON ending in a newline)
const real = {
  async connect() {
    const dev = await navigator.bluetooth.requestDevice({ filters: [{ services: [SERVICE] }] });
    const server = await dev.gatt.connect();
    const svc = await server.getPrimaryService(SERVICE);
    this.write = await svc.getCharacteristic(WRITE_CHAR);
    const notify = await svc.getCharacteristic(NOTIFY_CHAR);
    this.buffer = "";
    await notify.startNotifications();
    notify.addEventListener("characteristicvaluechanged", e => {
      this.buffer += new TextDecoder().decode(e.target.value);
      if (this.buffer.endsWith("\n") && this.waiting) { const r = JSON.parse(this.buffer); this.buffer = ""; this.waiting(r); }
    });
    return dev.name || "seat hub";
  },
  async sendFrame(m, i, n, chunk) {
    const packet = new Uint8Array(4 + chunk.length);
    packet.set([m >> 8, m & 255, i, n]); packet.set(chunk, 4);
    const reply = i === n - 1 ? new Promise(res => { this.waiting = res; }) : null;
    await this.write.writeValueWithoutResponse(packet);
    return reply ? reply : { ack: i };
  },
  async read() { return { found: false }; }
};

// ---------- Connect ----------
async function connect(useReal) {
  try {
    const st = await (await fetch("/bt/status")).json();
    if (!st.connected) throw new Error("not linked to the galley yet");
    const name = st.device;
    transport = simulated;
    connected = true;
    const pill = document.getElementById("ble-pill");
    pill.textContent = "Bluetooth: connected to " + name;
    pill.className = "pill on";
    document.getElementById("editor").classList.remove("hidden");
    await loadCurrent(true);
  } catch (e) {
    document.getElementById("ble-pill").textContent = "Bluetooth: " + (e.message || "failed");
  }
}

// ---------- Current meal and Dietary Passport (a Bluetooth read) ----------
function fillFrom(p) {
  document.querySelector(`input[name="diet"][value="${p.diet}"]`).checked = true;
  const spice = ["low", "mild", "spicy"].includes(p.spice) ? p.spice : "mild";
  document.querySelector(`input[name="spice"][value="${spice}"]`).checked = true;
  savedMeat = VEG_DIETS.includes(p.diet) ? { beef: false, pork: false } : null;
  document.getElementById("noBeef").checked = p.noBeef;
  document.getElementById("noPork").checked = p.noPork;
  document.getElementById("severe").checked = p.severe;
  document.querySelectorAll('input[name="allergy"]').forEach(b => { b.checked = p.allergies.includes(b.value); });
  customAllergies = p.custom.slice();
  likes = (p.likes || []).slice(0, 3);
  drawChips(); drawLikes(); syncMeatBoxes();
}

function passportLine(p) {
  if (!p) return "";
  const via = { BOOKING: "booking", APP: "the app", BLUETOOTH: "Bluetooth" }[p.via] || p.via;
  return `<div class="hint">🛂 Dietary Passport <b>v${p.version}</b> · updated ${esc(p.updated)} via ${esc(via)}`
    + (p.pendingSync ? " · syncs to the ground after landing" : "") + "</div>";
}

async function loadCurrent(prefill) {
  if (!connected) return;
  const seat = document.getElementById("seat").value.trim().toUpperCase();
  const data = await transport.read(seat);
  const card = document.getElementById("current-card");
  card.classList.remove("hidden");
  if (!data.found) {
    document.getElementById("current").innerHTML = '<p class="hint">No meal booked for this seat yet. Sending your choices will book the best safe meal.</p>' + passportLine(data.passport);
    if (prefill && data.passport) fillFrom(data.passport.prefs);
    return;
  }
  const r = data.request;
  document.getElementById("current").innerHTML =
    `<b>${esc(r.meal)}</b> · seat ${esc(r.seat)} · <span class="tag">${esc(r.status)}</span>` + (r.kcal ? ` · ~${r.kcal} kcal` : "") +
    (r.components ? `<div class="hint">${esc(r.components)}</div>` : "") +
    (r.note ? `<div class="alert">${esc(r.note)}</div>` : "") + passportLine(data.passport);
  if (prefill) fillFrom(data.passport ? data.passport.prefs : r);
}

function addLike() {
  const input = document.getElementById("like-input");
  const w = input.value.trim().toLowerCase();
  if (w && !likes.includes(w) && likes.length < 3) likes.push(w);
  input.value = "";
  drawLikes();
}
function removeLike(i) { likes.splice(i, 1); drawLikes(); }
function drawLikes() {
  document.getElementById("like-chips").innerHTML = likes
    .map((w, i) => `<span class="chip">♥ ${esc(w)} <a onclick="removeLike(${i})">×</a></span>`).join("");
}

function addCustom() {
  const input = document.getElementById("custom-input");
  const w = input.value.trim().toLowerCase();
  if (w && !customAllergies.includes(w) && customAllergies.length < 5) customAllergies.push(w);
  input.value = "";
  drawChips();
}
function removeCustom(i) { customAllergies.splice(i, 1); drawChips(); }
function drawChips() {
  document.getElementById("custom-chips").innerHTML = customAllergies
    .map((w, i) => `<span class="chip warn">⚠ ${esc(w)} <a onclick="removeCustom(${i})">×</a></span>`).join("");
}

// ---------- Send over Bluetooth, with retries ----------
async function send() {
  if (busy || !connected) return;
  busy = true;
  document.getElementById("send-btn").disabled = true;
  document.getElementById("result-card").classList.add("hidden");

  const payload = buildPayload();
  const bytes = toBytes(payload);
  const m = 1 + Math.floor(Math.random() * 65000);
  const n = Math.ceil(bytes.length / FRAME_DATA);
  const weak = document.getElementById("weak").checked;

  document.getElementById("tx-card").classList.remove("hidden");
  document.getElementById("tx-payload").textContent = payload;
  document.getElementById("tx-info").textContent =
    `${bytes.length} bytes (text + 4-byte CRC check) → ${n} Bluetooth frames of up to ${FRAME_DATA} bytes. Message #${m}.`;
  const boxes = document.getElementById("tx-frames");
  boxes.innerHTML = Array.from({ length: n }, (_, i) => `<i id="f${i}">${i + 1}</i>`).join("");
  const status = document.getElementById("tx-status");

  let retries = 0, reply = null;
  try {
    for (let i = 0; i < n && !reply; i++) {
      const chunk = bytes.slice(i * FRAME_DATA, (i + 1) * FRAME_DATA);
      for (let attempt = 1; ; attempt++) {
        document.getElementById("f" + i).className = attempt > 1 ? "retry" : "now";
        status.textContent = `Sending frame ${i + 1} of ${n}` + (attempt > 1 ? ` (retry ${attempt - 1})` : "") + "...";
        await sleep(weak ? 150 : 90);
        if (weak && attempt < 6 && Math.random() < 0.25) { retries++; await sleep(250); continue; }      // packet lost in the air
        const r = await transport.sendFrame(m, i, n, chunk);
        if (weak && attempt < 6 && Math.random() < 0.15) { retries++; await sleep(250); continue; }       // our ack was lost: send again
        if (r.error && !r.complete) throw new Error(r.error);
        if (r.complete) reply = r;
        break;
      }
      document.getElementById("f" + i).className = "sent";
    }
    if (!reply) throw new Error("no reply from the hub");
    status.textContent = `All ${n} frames delivered` + (retries ? ` after ${retries} retr${retries === 1 ? "y" : "ies"}.` : ".");
    showResult(reply);
  } catch (e) {
    status.textContent = "Transmission failed: " + e.message;
  }
  busy = false;
  document.getElementById("send-btn").disabled = false;
  loadCurrent(false);
}

function showResult(r) {
  const box = document.getElementById("result");
  if (!r.ok) {
    box.innerHTML = `<div class="outcome warn"><b>Not accepted.</b> ${esc(r.error)}${r.resend ? " Please press Send again." : ""}</div>`;
  } else {
    const warn = r.outcome === "CHANGED" || r.outcome === "TOO_LATE";
    let html = `<div class="outcome ${warn ? "warn" : ""}"><b>${esc(r.message)}</b>${r.kcal ? `<div class="hint">About ${r.kcal} kcal</div>` : ""}</div>`;
    if (r.passport) {
      html += `<div class="outcome">🛂 <b>Dietary Passport updated automatically</b> (v${r.passport.version}, ${esc(r.passport.updated)}).`
        + (r.passport.changes.length ? `<br>${r.passport.changes.map(esc).join(" · ")}` : "<br>No preference changed.")
        + `<div class="hint">Saved on the aircraft over Bluetooth, no Wi-Fi needed. It syncs to the ground system after landing.</div></div>`;
    }
    if (r.expansions.length) {
      html += "<p class='hint'><span class='aitag'>AI</span> " + r.expansions.map(e => `For "${esc(e.term)}" the server avoids: ${esc(e.keywords.join(", "))}`).join(". ") + ".</p>";
    }
    if (r.removed.length) {
      html += "<p class='hint'>Meals removed for you:</p>" + r.removed.map(x =>
        `<div class="removed-item">✕ <b>${esc(x.name)}</b> · ${x.reason.startsWith("AI flagged") ? '<span class="aitag">AI</span> ' : ""}${esc(x.reason)}</div>`).join("");
    }
    if (r.verify) html += "<p class='hint'>⚠ Allergy changes are re-checked by the crew before serving. Please also tell them about severe allergies.</p>";
    box.innerHTML = html;
  }
  document.getElementById("result-card").classList.remove("hidden");
}

syncMeatBoxes();
setInterval(() => { if (connected && !busy && transport === simulated) loadCurrent(false); }, 3000);

// Join the Bluetooth link automatically as soon as the bridge has it.
(function auto() { if (connected) return; connect(false).finally(() => { if (!connected) setTimeout(auto, 3000); }); })();
