// Small badge in the top-right corner: is the Bluetooth link to the galley laptop alive?
(function () {
  const pill = document.createElement("div");
  pill.style.cssText = "position:fixed;top:10px;right:12px;z-index:50;padding:6px 12px;border-radius:999px;font:600 13px system-ui;color:#fff;box-shadow:0 2px 6px rgba(0,0,0,.25)";
  document.body.appendChild(pill);
  async function tick() {
    try {
      const s = await (await fetch("/bt/status", { cache: "no-store" })).json();
      const ok = s.connected && s.linked;
      pill.style.background = ok ? "#1b8a4b" : "#c0392b";
      pill.textContent = ok ? "\u{1F4F6} Bluetooth: linked to " + s.device + (s.mode === "simulated" ? " (test)" : "")
                            : "\u{1F4F6} Bluetooth: " + (s.error || "reconnecting...");
    } catch (e) { pill.style.background = "#c0392b"; pill.textContent = "Bluetooth bridge not running"; }
  }
  tick(); setInterval(tick, 2000);
})();
