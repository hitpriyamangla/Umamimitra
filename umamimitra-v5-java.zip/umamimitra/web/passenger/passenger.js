// Passenger screen: choose preferences, see safe meals, reserve, track. Also the Dietary Passport.

let myRequestId = null;        // set after the passenger reserves
let customAllergies = [];      // allergies the passenger typed themselves
let likes = [];                // foods the passenger prefers
let lastMeals = "";            // used to redraw only when something changed
let savedMeat = null;          // beef/pork ticks to restore if a veg diet is un-selected
let passportVersion = null;    // last passport version we saw

// ---- Read what the passenger selected ----

function getDiet() {
  const chosen = document.querySelector('input[name="diet"]:checked');
  return chosen ? chosen.value : null;
}
function getSpice() { return document.querySelector('input[name="spice"]:checked').value; }
function getAllergies() {
  return Array.from(document.querySelectorAll('input[name="allergy"]:checked')).map(b => b.value);
}
const pidValue = () => document.getElementById("pid").value.trim().toLowerCase();

// The passenger's choices as a web address query
function preferences() {
  return new URLSearchParams({
    diet: getDiet() || "vegetarian",
    noBeef: document.getElementById("noBeef").checked,
    noPork: document.getElementById("noPork").checked,
    allergies: getAllergies().join(","),
    custom: customAllergies.join(","),
    likes: likes.join(","),
    severe: document.getElementById("severe").checked,
    spice: getSpice()
  });
}

// ---- Vegetarian, vegan and Jain mean no meat: beef AND pork (and chicken, fish) are all excluded ----

function syncMeatBoxes() {
  const beef = document.getElementById("noBeef"), pork = document.getElementById("noPork");
  const note = document.getElementById("meat-note");
  if (VEG_DIETS.includes(getDiet())) {
    if (!savedMeat) savedMeat = { beef: beef.checked, pork: pork.checked };
    beef.checked = pork.checked = true;
    beef.disabled = pork.disabled = true;
    note.textContent = "Your diet already excludes all meat: beef, pork, chicken and fish.";
  } else {
    beef.disabled = pork.disabled = false;
    if (savedMeat) { beef.checked = savedMeat.beef; pork.checked = savedMeat.pork; savedMeat = null; }
    note.textContent = "";
  }
}

// ---- Ask the Java server which meals are safe ----

async function loadMeals() {
  if (getDiet() === null) return;
  const data = await api("/api/meals?" + preferences());

  const snapshot = JSON.stringify(data);
  if (snapshot === lastMeals) return;       // nothing changed: do not redraw (keeps "Ingredients" open)
  lastMeals = snapshot;

  showAvailable(data);
  showRemoved(data.removed);
}

function showAvailable(data) {
  const list = document.getElementById("meal-list");
  const diet = getDiet();
  let html = "";
  let dividerShown = false;
  const anyPrimary = data.available.some(m => m.primary);

  data.available.forEach((meal, i) => {
    if (!meal.primary && !dividerShown && anyPrimary) {
      dividerShown = true;
      html += `<div class="divider">${diet === "nonveg" ? "Vegetarian options (shown last)" : "Also suits your diet"}</div>`;
    }
    const best = i === 0 && meal.primary && meal.spiceMatch;
    const contains = meal.allergens.length ? meal.allergens.map(a => ALLERGEN_NAMES[a]).join(", ") : "none of our listed allergens";
    html += `
      <div class="meal ${best ? "best" : ""} ${meal.primary ? "" : "secondary"}">
        <div>
          <h3>${esc(meal.name)} ${best ? '<span class="badge">Best match</span>' : ""}</h3>
          <p>${esc(meal.description)} ${meal.spice ? "🌶".repeat(meal.spice) : "· no heat"}</p>
          <p class="nut"><b>${nutLine(meal.nutrition)}</b></p>
          <p>Contains: ${contains} · ${meal.stock} left</p>
          <details><summary>Ingredients</summary>${meal.ingredients.map(esc).join(", ")}</details>
        </div>
        <button onclick="reserveMeal('${meal.id}')">Reserve</button>
      </div>`;
  });

  // No whole meal is safe: offer a custom safe plate (or ask the crew)
  if (data.available.length === 0) {
    html += "<p class='hint'>No standard meal is safe for you.</p>";
    if (data.plate && data.plate.possible) {
      html += `
        <div class="plate-card">
          <b>We can make you a custom safe plate</b>
          <ul>${data.plate.items.map(i => `<li>${esc(i)}</li>`).join("")}</ul>
          <p class="nut"><b>${nutLine(data.plate.nutrition)}</b></p>
          <p class="hint">Plain, sealed galley components, each checked against your allergies. Assembled by the crew.</p>
          <button onclick="reserveMeal('PLATE')">Reserve custom plate</button>
        </div>`;
    } else if (data.plate) {
      html += `
        <div class="plate-card">
          <b>We could not build a safe plate from the galley stock.</b>
          <p class="hint">The crew will arrange a safe alternative and speak to you.</p>
          <button onclick="reserveMeal('CREW')">Ask the crew to arrange something</button>
        </div>`;
    }
  }

  if (data.verify) {
    html += "<p class='hint'>⚠ Allergy requests are double-checked by the crew before serving. Ingredient lists cannot cover every trace, so please also tell the crew about severe allergies.</p>";
  }
  list.innerHTML = html;
}

function showRemoved(removed) {
  const card = document.getElementById("removed-card");
  if (removed.length === 0) { card.classList.add("hidden"); return; }
  document.getElementById("removed-list").innerHTML = removed
    .map(item => `<div class="removed-item">✕ <b>${esc(item.name)}</b> · ${esc(item.reason)}</div>`)
    .join("");
  card.classList.remove("hidden");
}

// ---- Allergies the passenger types themselves ----

async function addCustom() {
  const input = document.getElementById("custom-input");
  const word = input.value.trim().toLowerCase();
  if (!word || customAllergies.includes(word) || customAllergies.length >= 5) { input.value = ""; return; }

  customAllergies.push(word);
  input.value = "";
  drawCustomChips();

  // Show what the AI will watch for
  const e = await api("/api/expand?text=" + encodeURIComponent(word), true);
  document.getElementById("custom-note").textContent =
    `For "${word}" we will avoid anything with: ${e.keywords.join(", ")}. (${e.source === "claude" ? "AI-expanded" : "built-in list"})`;
  loadMeals();
}

function removeCustom(index) {
  customAllergies.splice(index, 1);
  drawCustomChips();
  document.getElementById("custom-note").textContent = "";
  loadMeals();
}

function drawCustomChips() {
  document.getElementById("custom-chips").innerHTML = customAllergies
    .map((w, i) => `<span class="chip warn">⚠ ${esc(w)} <a onclick="removeCustom(${i})">×</a></span>`).join("");
}

// ---- Foods the passenger prefers ----

function addLike() {
  const input = document.getElementById("like-input");
  const word = input.value.trim().toLowerCase();
  if (word && !likes.includes(word) && likes.length < 3) likes.push(word);
  input.value = "";
  drawLikeChips();
  loadMeals();
}
function removeLike(i) { likes.splice(i, 1); drawLikeChips(); loadMeals(); }
function drawLikeChips() {
  document.getElementById("like-chips").innerHTML = likes
    .map((w, i) => `<span class="chip">♥ ${esc(w)} <a onclick="removeLike(${i})">×</a></span>`).join("");
}

// ---- Fill the form from a parsed request or from a passport ----

function fillForm(p) {
  document.querySelector(`input[name="diet"][value="${p.diet}"]`).checked = true;
  // For a veg diet the beef/pork ticks are automatic, so un-locking later must clear them, not keep them.
  savedMeat = VEG_DIETS.includes(p.diet) ? { beef: false, pork: false } : null;
  document.getElementById("noBeef").checked = p.noBeef;
  document.getElementById("noPork").checked = p.noPork;
  const spice = ["low", "mild", "spicy"].includes(p.spice) ? p.spice : "mild";
  document.querySelector(`input[name="spice"][value="${spice}"]`).checked = true;
  document.querySelectorAll('input[name="allergy"]').forEach(box => { box.checked = p.allergies.includes(box.value); });
  document.getElementById("severe").checked = p.severe;
  customAllergies = p.custom.slice();
  likes = (p.likes || []).slice(0, 3);
  drawCustomChips();
  drawLikeChips();
  syncMeatBoxes();
  lastMeals = "";
  loadMeals();
}

// ---- AI reading of a typed request ----

async function understand() {
  const text = document.getElementById("free-text").value;
  if (!text.trim()) return;

  const p = await api("/api/parse?text=" + encodeURIComponent(text), true);
  fillForm(p);

  const parts = [DIET_NAMES[p.diet], p.noBeef ? "no beef" : "", p.noPork ? "no pork" : "",
    VEG_DIETS.includes(p.diet) ? "no chicken or fish" : "",
    p.allergies.length ? "allergic to " + p.allergies.map(a => ALLERGEN_NAMES[a]).join(", ") : "",
    p.custom.length ? "also allergic to " + p.custom.join(", ") : "",
    p.likes.length ? "prefers " + p.likes.join(", ") : "",
    SPICE_NAMES[p.spice] + " spice"].filter(Boolean);
  document.getElementById("parse-note").textContent =
    "We understood: " + parts.join(", ") + ". Please check the boxes below. (read by: " + (p.source === "claude" ? "AI" : "keyword rules") + ")";
}

// ---- Dietary Passport ----

function showPassport(p, notify) {
  const status = document.getElementById("passport-status");
  const notice = document.getElementById("passport-notice");
  if (!p.found) { status.textContent = "No passport found for this login id yet."; return; }
  const via = { BOOKING: "booking", APP: "the app", BLUETOOTH: "Bluetooth on board" }[p.via] || p.via;
  status.innerHTML = `Passport <b>v${p.version}</b> · last updated ${esc(p.updated)} via ${esc(via)}`
    + (p.pendingSync ? " · <span class='chip warn'>changed on board, syncs to the ground after landing</span>" : "")
    + (p.preOrder ? `<br>Pre-order: <b>${esc(p.preOrder)}</b>` : "")
    + `<details><summary>History</summary>${p.history.map(esc).join("<br>")}</details>`;
  if (notify && passportVersion !== null && p.version !== passportVersion && p.via === "BLUETOOTH") {
    notice.innerHTML = `🔄 Your passport was updated over Bluetooth (v${p.version}). <button type="button" onclick="loadPassport()">Load it into the form</button>`;
    notice.classList.remove("hidden");
  }
  passportVersion = p.version;
}

async function loadPassport() {
  const id = pidValue();
  if (id.length < 3) return;
  const p = await api("/api/passport?id=" + encodeURIComponent(id));
  document.getElementById("passport-notice").classList.add("hidden");
  showPassport(p, false);
  if (p.found) fillForm(p.prefs);
}

async function savePassport() {
  const id = pidValue();
  if (id.length < 3) return;
  const params = preferences();
  params.set("id", id);
  params.set("seat", document.getElementById("seat").value || "18A");
  const p = await api("/api/passport/save?" + params, true);
  showPassport(p, false);
}

async function pollPassport() {
  const id = pidValue();
  if (id.length < 3) return;
  const p = await api("/api/passport?id=" + encodeURIComponent(id));
  if (p.found) showPassport(p, true);
}

// ---- Reserve ----

async function reserveMeal(mealId) {
  const params = preferences();
  params.set("mealId", mealId);
  params.set("seat", document.getElementById("seat").value || "18A");
  params.set("pid", pidValue());                 // the pre-order also goes into the Dietary Passport

  const result = await api("/api/reserve?" + params, true);

  const box = document.getElementById("confirmation");
  box.textContent = (result.success ? "✓ " : "") + result.message + (result.success && result.passport ? " Saved to your Dietary Passport." : "");
  box.className = "message" + (result.success ? "" : " error");

  if (result.success) myRequestId = result.id;
  lastMeals = "";
  loadMeals();
  trackMyRequest();
  pollPassport();
}

// ---- Tracker ----

async function trackMyRequest() {
  if (myRequestId === null) return;
  const all = await api("/api/requests");
  const mine = all.find(r => r.id === myRequestId);
  if (!mine) return;

  const steps = ["RESERVED", "ACKNOWLEDGED", "SERVED"];
  const labels = ["Reserved", "Crew acknowledged", "Served"];
  const reached = steps.indexOf(mine.status);

  document.getElementById("tracker-meal").innerHTML =
    `<b>${esc(mine.meal)}</b> · seat ${esc(mine.seat)}` + (mine.kcal ? ` · ~${mine.kcal} kcal` : "")
    + (mine.components ? `<div class="hint">${esc(mine.components)}</div>` : "")
    + (mine.note ? `<div class="alert">${esc(mine.note)}</div>` : "");
  document.getElementById("tracker").innerHTML = labels
    .map((label, i) => `<div class="${i <= reached ? "done" : ""}">${i <= reached ? "✓ " : ""}${label}</div>`).join("");
  document.getElementById("tracker-card").classList.remove("hidden");
}

// ---- Start ----
document.getElementById("prefs").addEventListener("change", () => { syncMeatBoxes(); loadMeals(); });
syncMeatBoxes();
setInterval(() => { trackMyRequest(); loadMeals(); pollPassport(); }, 5000);
