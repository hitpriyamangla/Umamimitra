// AI Forecast page: demand per meal, custom plates, extras to stock. Data comes from /api/forecast.

let asked = false;      // true after "Ask AI to explain": keep that wording until the next reset

async function refresh() {
  const d = await api("/api/forecast" + (asked ? "?explain=1" : ""));
  document.getElementById("rate").textContent = Math.round(d.unexpectedRate * 100);
  document.getElementById("s-pax").textContent = d.passengers;
  document.getElementById("s-pre").textContent = d.preOrdered;
  document.getElementById("s-pending").textContent = d.pending;
  document.getElementById("s-unexp").textContent = d.unexpected;

  if (d.passengers === 0) { document.getElementById("briefing").textContent = "No passports yet. Press the demo button, or book a meal on the Passenger page."; return; }
  document.getElementById("briefing").textContent = d.briefing;
  document.getElementById("brief-src").textContent = d.source === "claude" ? "worded by Claude" : "rules";

  const p = d.plates;
  document.getElementById("plates-total").textContent = p.recommended;
  document.getElementById("plates-split").textContent =
    `${p.definite} certain (their passport leaves no safe whole meal) + ${p.atRisk} at risk (only one safe meal, likely to sell out) + ${p.buffer} buffer for unexpected orders. Already reserved: ${p.existing}.`
    + (p.crewNeeded ? ` ${p.crewNeeded} passenger(s) have no safe plate even with current stock: see extras.` : "");

  document.getElementById("components").innerHTML = d.components.length ? d.components.map(c => `
    <tr><td>${esc(c.name)}</td><td>${c.need}</td><td>${c.stock}</td>
    <td>${c.shortfall ? `<span class="status-pill pill-SHORT">Add ${c.shortfall}</span>` : '<span class="status-pill pill-OK">Enough</span>'}</td></tr>`).join("")
    : '<tr><td colspan="4" class="hint">No plates predicted.</td></tr>';

  document.getElementById("meals").innerHTML = d.meals.map(m => `
    <tr><td><b>${esc(m.name)}</b></td><td>${m.stock}</td><td>${m.expected}</td><td>+${m.buffer}</td><td><b>${m.recommended}</b></td>
    <td><span class="status-pill pill-${m.status}">${m.status === "SHORT" ? "Short by " + m.gap : m.status === "SURPLUS" ? "Surplus" : "OK"}</span></td></tr>`).join("");

  document.getElementById("extras").innerHTML = d.extras.length ? d.extras.map(e => `
    <div class="meal"><div>
      <h3>${esc(e.name)} <span class="badge">+${e.qty}</span></h3>
      <p>${esc(e.kind)} · $${e.unit.toFixed(2)} each · $${e.total.toFixed(2)} total</p>
      <p>Helps: ${e.serves.map(esc).join("; ")}</p></div></div>`).join("")
    : '<p class="hint">No extras needed: every tested combination is covered by current stock.</p>';

  document.getElementById("gaps").innerHTML = d.gaps.length ? d.gaps.map(g => `
    <tr><td>${esc(g.label)}</td>
    <td>${g.capacity} / ${g.need} <span class="status-pill pill-${g.state}">${g.state === "NO_PLATE" ? "nothing safe" : "thin"}</span></td>
    <td>${g.fixed ? `<span class="status-pill pill-FIXED">${g.after} ✓</span>` : '<span class="status-pill pill-SHORT">still short: crew arranges</span>'}</td></tr>`).join("")
    : '<tr><td colspan="3" class="hint">None.</td></tr>';
}

async function seed() { asked = false; await api("/api/manifest/seed?n=150&pre=55", true); refresh(); }
async function explain() { asked = true; document.getElementById("briefing").textContent = "Asking the AI..."; refresh(); }

refresh();
setInterval(() => { if (!asked) refresh(); }, 4000);
