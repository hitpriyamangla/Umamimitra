// Crew screen: see each passenger's request, acknowledge it, mark it served.

function requestCard(r) {
  // Which button to show depends on how far the request has come
  let button = "";
  if (r.status === "RESERVED") {
    button = `<button onclick="setStatus(${r.id}, 'ACKNOWLEDGED')">✓ Acknowledge</button>`;
  } else if (r.status === "ACKNOWLEDGED") {
    button = `<button class="green" onclick="setStatus(${r.id}, 'SERVED')">Mark as served</button>`;
  }

  // Extra instructions for special kinds of request
  let extra = "";
  if (r.amended) {
    extra += `<div class="alert">🔄 CHANGED IN FLIGHT over Bluetooth at ${esc(r.updated)}. ${esc(r.note)} Re-check allergies before serving.</div>`;
  }
  if (r.kind === "PLATE") {
    extra = `<div class="alert">🍽 Custom plate. Assemble from sealed galley components: ${esc(r.components)}</div>`;
  }
  if (r.kind === "CREW") {
    extra = `<div class="alert">⚠ No safe meal could be found. Please speak to the passenger and arrange a safe alternative.</div>`;
  }
  if (r.severe) {
    extra += `<div class="alert severe">🚨 SEVERE ALLERGY reported. Tell the purser and verify every ingredient before serving.</div>`;
  }
  if (hasAllergy(r)) {
    extra += `<div class="alert">⚠ Allergy: ${esc(allergyText(r))}. Check ingredients before serving.</div>`;
  }

  return `
    <div class="req ${r.status === "RESERVED" ? "new" : ""} ${r.severe ? "severe" : ""}">
      <div class="seat">Seat ${esc(r.seat)} <span class="hint">· ${esc(r.time)}</span></div>
      <div><b>${esc(r.meal)}</b>${r.kcal ? ` <span class="hint">· ~${r.kcal} kcal</span>` : ""}</div>
      <div>${requestTags(r).map(t => `<span class="tag">${esc(t)}</span>`).join("")}${r.channel === "BLUETOOTH" ? '<span class="tag">Bluetooth</span>' : ""}</div>
      ${extra}
      <div class="buttons">${button}</div>
    </div>`;
}

const TYPE_NAMES = { JAIN: "Jain", VEGAN: "Vegan", VEGETARIAN: "Vegetarian", NON_VEG: "Non-veg" };
const STATUS_NAMES = { RESERVED: "Reserved", ACKNOWLEDGED: "Crew acknowledged", SERVED: "Served" };
const KIND_NAMES = { MAIN: "Main", CARB: "Carb", SIDE: "Side" };


// ---------- Galley screen: crew + caterer in one view, fed live by the Bluetooth hub ----------
const HUB = "http://localhost:3002/status";
let prev = null, feed = [], soundOn = false, audio = null;

function beep(urgent) {
  if (!soundOn) return;
  try {
    audio = audio || new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.18].slice(0, urgent ? 2 : 1).forEach(t => {
      const o = audio.createOscillator(), g = audio.createGain();
      o.frequency.value = urgent ? 880 : 660; o.connect(g); g.connect(audio.destination);
      g.gain.setValueAtTime(0.15, audio.currentTime + t); g.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + t + 0.15);
      o.start(audio.currentTime + t); o.stop(audio.currentTime + t + 0.16);
    });
  } catch (e) {}
}
function toggleSound() {
  soundOn = !soundOn; document.getElementById("sound-btn").textContent = soundOn ? "🔔 Sound on" : "🔕 Sound off"; beep(false);
}

function notify(text, urgent) {
  feed.unshift({ t: new Date().toLocaleTimeString(), text, urgent });
  feed = feed.slice(0, 8);
  document.getElementById("feed").innerHTML = feed.map(f =>
    `<div class="${f.urgent ? "alert severe" : "alert"}"><b>${esc(f.t)}</b> ${esc(f.text)}</div>`).join("");
  const flash = document.getElementById("flash");
  flash.textContent = "📡 " + text; flash.className = "flash show" + (f_urgent(urgent)); 
  clearTimeout(notify.timer); notify.timer = setTimeout(() => flash.className = "flash", 9000);
  beep(urgent);
}
const f_urgent = u => u ? " urgent" : "";

function diffRequests(list) {
  const now = new Map(list.map(r => [r.id, r]));
  if (prev) {
    for (const r of list) {
      const old = prev.get(r.id);
      const via = r.channel === "BLUETOOTH" ? " over Bluetooth" : "";
      if (!old) {
        notify(`New request, seat ${r.seat}: ${r.meal}${via}` + (hasAllergy(r) ? `. ALLERGY: ${allergyText(r)}` : ""), r.severe);
      } else if (r.amended && (old.updated !== r.updated || old.meal !== r.meal)) {
        notify(`Seat ${r.seat} CHANGED IN FLIGHT${via}: now ${r.meal}. ${r.note || ""}`, true);
      } else if (old.meal !== r.meal || hasAllergy(old) !== hasAllergy(r) || allergyText(old) !== allergyText(r)) {
        notify(`Seat ${r.seat} updated: ${r.meal}` + (hasAllergy(r) ? `. ALLERGY: ${allergyText(r)}` : ""), r.severe);
      }
    }
  }
  prev = now;
}

async function refreshHub() {
  const pill = document.getElementById("hub-pill"), info = document.getElementById("hub-info");
  try {
    const h = await (await fetch(HUB, { cache: "no-store" })).json();
    pill.className = "pill " + (h.linked ? "on" : "off");
    pill.textContent = h.linked ? "Bluetooth: passenger laptop linked" + (h.mode === "simulated" ? " (test mode)" : "") : "Bluetooth: waiting for passenger laptop";
    info.textContent = `${h.stats.requests} messages received · ${h.stats.replays} repeats ignored · ${h.stats.bad_crc} damaged` + (h.last.path ? ` · last ${h.last.time}: ${h.last.path}` : "");
  } catch (e) {
    pill.className = "pill off"; pill.textContent = "Bluetooth hub not running"; info.textContent = "Run "Galley Hub" in IntelliJ on this laptop.";
  }
}

async function refresh() {
  const [requests, inventory] = await Promise.all([api("/api/requests"), api("/api/inventory")]);
  diffRequests(requests);

  const todo = requests.filter(r => r.status !== "SERVED").sort((a, b) => (b.severe ? 1 : 0) - (a.severe ? 1 : 0));
  const done = requests.filter(r => r.status === "SERVED");
  document.getElementById("todo").innerHTML = todo.length ? todo.map(requestCard).join("") : '<div class="card hint">No requests waiting.</div>';
  document.getElementById("done").innerHTML = done.length ? done.slice(0, 4).map(requestCard).join("") : '<div class="card hint">Nothing served yet.</div>';

  document.getElementById("stat-requests").textContent = requests.length;
  document.getElementById("stat-allergy").textContent = requests.filter(hasAllergy).length;
  document.getElementById("stat-severe").textContent = requests.filter(r => r.severe).length;
  document.getElementById("stat-plates").textContent = requests.filter(r => r.kind !== "MEAL").length;
  document.getElementById("stat-bt").textContent = requests.filter(r => r.channel === "BLUETOOTH").length;

  document.getElementById("inventory").innerHTML = inventory.meals.map(m => {
    const low = m.stock <= 2, pct = Math.round((m.stock / m.start) * 100);
    return `<tr><td><b>${esc(m.name)}</b><br><span class="hint">${TYPE_NAMES[m.type]} · ${m.nutrition.kcal} kcal</span></td>
      <td><span class="${low ? "low-text" : ""}">${m.start === m.stock ? m.stock : m.start + " → " + m.stock}${low ? " · LOW" : ""}</span>
      <div class="bar ${low ? "low" : ""}"><div style="width:${pct}%"></div></div></td></tr>`;
  }).join("");
  document.getElementById("components").innerHTML = inventory.components.map(c =>
    `<tr><td>${esc(c.name)}</td><td>${KIND_NAMES[c.kind]}</td><td>${c.start === c.stock ? c.stock : c.start + " → " + c.stock}</td></tr>`).join("");
}

async function setStatus(id, status) { await api("/api/status?id=" + id + "&status=" + status, true); refresh(); }
async function simulate() { await api("/api/simulate?n=120", true); refresh(); }
async function resetDemo() { await api("/api/reset", true); prev = null; feed = []; document.getElementById("feed").innerHTML = ""; refresh(); }

refresh(); refreshHub();
setInterval(refresh, 1500);
setInterval(refreshHub, 2000);
