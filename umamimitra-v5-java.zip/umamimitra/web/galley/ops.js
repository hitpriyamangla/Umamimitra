// Planning page: see what sold, edit the next-flight load, approve it.

const PILL_NAMES = { SOLD_OUT: "Sold out", LOW: "Low", UNDERUSED: "Under-used", OK: "OK" };

let built = false;          // is the table drawn yet?
let costs = {};             // meal id -> cost per portion
let currentLoadCost = 0;

async function refresh() {
  const d = await api("/api/planner");
  currentLoadCost = d.currentLoadCost;

  document.getElementById("sum-load").textContent = money(d.currentLoadCost);
  document.getElementById("sum-left").textContent = money(d.leftoverValue);
  document.getElementById("sum-avoid").textContent = money(d.wasteAvoided);

  // Draw the table once. Later refreshes only update the text, so typing is never interrupted.
  if (!built) {
    document.getElementById("plan-body").innerHTML = d.rows.map(r => `
      <tr>
        <td><b>${esc(r.name)}</b></td>
        <td id="load-${r.id}"></td>
        <td id="status-${r.id}"></td>
        <td id="advice-${r.id}"></td>
        <td><input class="qty" type="number" min="0" max="500" id="qty-${r.id}" value="${r.suggest}"
                   oninput="this.dataset.edited='1'; updateCost()"></td>
      </tr>`).join("");
    built = true;
  }

  for (const r of d.rows) {
    costs[r.id] = r.cost;
    document.getElementById("load-" + r.id).textContent = r.start + " → " + r.stock;
    document.getElementById("status-" + r.id).innerHTML =
      `<span class="status-pill pill-${r.status}">${PILL_NAMES[r.status]}</span>`;
    let advice = `<span class="note">keep ${r.start}</span>`;
    if (r.delta > 0) advice = `<span class="up">↑ ${r.suggest} (+${r.delta})</span>`;
    if (r.delta < 0) advice = `<span class="down">↓ ${r.suggest} (${r.delta})</span>`;
    document.getElementById("advice-" + r.id).innerHTML = advice;

    const input = document.getElementById("qty-" + r.id);
    input.dataset.suggest = r.suggest;
    if (!input.dataset.edited) input.value = r.suggest;      // follow the advice until the user edits
  }
  updateCost();
  showApproved(d.approved);
}

// Cost of the plan currently typed in, compared with today's load
function updateCost() {
  let total = 0;
  for (const id in costs) total += Number(document.getElementById("qty-" + id).value || 0) * costs[id];
  const diff = total - currentLoadCost;
  document.getElementById("new-cost").textContent =
    `New load cost: ${money(total)} (${diff >= 0 ? "+" : "−"}${money(Math.abs(diff))} vs current load)`;
}

function useAdvice() {
  for (const id in costs) {
    const input = document.getElementById("qty-" + id);
    delete input.dataset.edited;
    input.value = input.dataset.suggest;
  }
  updateCost();
}

async function approve() {
  const plan = Object.keys(costs).map(id => id + ":" + (document.getElementById("qty-" + id).value || 0)).join(",");
  await api("/api/approve?plan=" + encodeURIComponent(plan), true);
  refresh();
}

function showApproved(a) {
  const box = document.getElementById("approved");
  if (!a) { box.classList.add("hidden"); return; }
  box.innerHTML = `<h2>✓ Plan approved at ${esc(a.time)}</h2>
    <p>Next-flight load cost: <b>${money(a.cost)}</b></p>
    <div>${a.rows.map(r => `<span class="chip">${esc(r.name)}: ${r.start} → ${r.qty}</span>`).join("")}</div>`;
  box.classList.remove("hidden");
}

async function simulate() { await api("/api/simulate?n=120", true); refresh(); }
async function resetDemo() {
  await api("/api/reset", true);
  built = false;                                  // redraw the table and clear edits
  refresh();
}

refresh();
setInterval(refresh, 2000);
