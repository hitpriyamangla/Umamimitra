// Monitor: what the seat hub and the AI back end are doing, live.

let lastLog = "", lastAnalysis = "";

async function refreshLog() {
  const d = await api("/api/ble/log");
  const snap = JSON.stringify(d);
  if (snap === lastLog) return;
  lastLog = snap;
  document.getElementById("s-frames").textContent = d.stats.frames;
  document.getElementById("s-msgs").textContent = d.stats.messages;
  document.getElementById("s-repeats").textContent = d.stats.repeats;
  document.getElementById("s-crc").textContent = d.stats.crcErrors;
  document.getElementById("ai-engine").textContent = d.ai;
  if (d.log.length) {
    document.getElementById("log").innerHTML = d.log.slice().reverse().map(l =>
      `<div class="logline k-${l.k}">${esc(l.t)} <b>${esc(l.k)}</b> ${esc(l.m)}</div>`).join("");
  }
}

async function refreshAnalysis() {
  const items = await api("/api/analysis");
  const snap = JSON.stringify(items);
  if (snap === lastAnalysis) return;
  lastAnalysis = snap;
  let html = "<tr><th>Item</th><th>Named in ingredients</th><th><span class='aitag'>AI</span> found hidden</th><th>Read by</th></tr>";
  for (const m of items) {
    const named = m.named.map(a => ALLERGEN_NAMES[a]).join(", ") || "-";
    const hidden = m.hidden.map(h => `<b>${esc(ALLERGEN_NAMES[h.allergen])}</b> in ${esc(h.ingredient)}<br><span class="hint">${esc(h.why)}</span>`).join("<br>") || "-";
    html += `<tr><td>${esc(m.name)}${m.kind !== "MEAL" ? ' <span class="hint">(galley)</span>' : ""}</td><td>${esc(named)}</td><td>${hidden}</td><td>${m.source === "claude" ? "Claude + rules" : "rules"}</td></tr>`;
  }
  document.getElementById("analysis").innerHTML = html;
}

refreshLog(); refreshAnalysis();
setInterval(refreshLog, 1500);
setInterval(refreshAnalysis, 5000);
