// Small helpers shared by all screens.

// Standard allergens. The first group is common in Indian meals, the second in Japanese meals.
const ALLERGEN_NAMES = {
  dairy: "Milk / dairy", gluten: "Wheat / gluten", mustard: "Mustard", coconut: "Coconut",
  buckwheat: "Buckwheat / soba", shellfish: "Shrimp / crab", soy: "Soy", fish: "Fish", sesame: "Sesame",
  peanuts: "Peanuts", treenuts: "Tree nuts", egg: "Egg"
};

const SPICE_NAMES = { low: "Low", mild: "Mild", spicy: "Spicy" };
const VEG_DIETS = ["vegetarian", "vegan", "jain"];

// "640 kcal · Protein 21 g · Carbs 92 g · Fat 20 g · Fibre 12 g" (estimates per portion)
function nutLine(n) {
  return `${n.kcal} kcal · Protein ${n.protein} g · Carbs ${n.carbs} g · Fat ${n.fat} g · Fibre ${n.fibre} g`;
}

const DIET_NAMES = { vegetarian: "Vegetarian", vegan: "Vegan", jain: "Jain", nonveg: "Non-vegetarian" };

async function api(url, isPost) {
  const response = await fetch(url, { method: isPost ? "POST" : "GET" });
  return response.json();
}

function esc(text) {
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function requestTags(r) {
  const tags = [DIET_NAMES[r.diet]];
  if (r.noBeef) tags.push("No beef");
  if (r.noPork) tags.push("No pork");
  if (r.spice === "spicy") tags.push("Spicy");
  if (r.spice === "mild") tags.push("Mild spice");
  if (r.spice === "low") tags.push("Low spice");
  return tags;
}

// All allergies of a request, standard and typed, as one readable text.
function allergyText(r) {
  return r.allergies.map(a => ALLERGEN_NAMES[a]).concat(r.custom).join(", ");
}

function hasAllergy(r) {
  return r.allergies.length > 0 || r.custom.length > 0;
}

function money(n) {
  return "$" + Number(n).toFixed(0);
}
