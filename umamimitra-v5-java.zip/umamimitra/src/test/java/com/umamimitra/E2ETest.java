package com.umamimitra;

import com.umamimitra.galley.Hub;
import com.umamimitra.galley.Main;
import com.umamimitra.link.MiniJson;
import com.umamimitra.link.Wire;
import com.umamimitra.passenger.Bridge;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * End-to-end test of BOTH laptops on ONE computer. No Bluetooth, no network, no libraries needed.
 *
 * Starts the Java server, the galley hub and the passenger bridge in this one program, drops 15% of all radio frames
 * and uses the smallest (20 byte) frames, then checks that a passenger's choice and an in-flight edit reach the galley data.
 * Run it from IntelliJ (green arrow next to main) or set LOSS=0 in the environment for a clean run.
 */
public class E2ETest {
    static final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    static final AtomicInteger failures = new AtomicInteger();

    static String call(String url, boolean post) throws Exception {
        HttpRequest r = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(90))
                .method(post ? "POST" : "GET", HttpRequest.BodyPublishers.noBody()).build();
        return http.send(r, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8)).body();
    }

    static Map<String, Object> flat(String json) { return MiniJson.parse(json); }

    static boolean check(String name, boolean ok) {
        System.out.println((ok ? "PASS " : "FAIL ") + name);
        if (!ok) failures.incrementAndGet();
        return ok;
    }

    static byte[] um2(String seat, String diet, String mask) {
        byte[] body = ("UM2|priya.k@demo|" + seat + "|" + diet + "|BP|" + mask + "|m||paneer|").getBytes(StandardCharsets.UTF_8);
        long crc = Wire.crc(body);
        byte[] out = java.util.Arrays.copyOf(body, body.length + 4);
        for (int i = 0; i < 4; i++) out[body.length + i] = (byte) (crc >> (24 - 8 * i));
        return out;
    }

    static String hex(byte[] b, int from, int to) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < to; i++) sb.append(String.format("%02x", b[i]));
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        double loss = Double.parseDouble(System.getenv().getOrDefault("LOSS", "0.15"));
        unitChecks();

        Main.main(new String[0]);
        Hub hub = new Hub("http://127.0.0.1:3000", 7777, 3002, true, loss);
        hub.start();
        Bridge bridge = new Bridge("127.0.0.1", 7777, 3001, 20, loss);
        bridge.start();
        for (int i = 0; i < 40 && !bridge.isConnected(); i++) Thread.sleep(500);
        check("passenger bridge linked to the galley hub", bridge.isConnected());

        String P = "http://localhost:3001", G = "http://localhost:3000";
        call(G + "/api/reset", true);
        long t = System.currentTimeMillis();
        String meals = call(P + "/api/meals?diet=vegetarian&noBeef=true&noPork=true&allergies=&custom=&likes=&severe=false&spice=mild", false);
        check("menu travels over the radio (" + meals.length() + " bytes of JSON, " + (System.currentTimeMillis() - t) / 1000.0 + "s)", meals.contains("\"available\":[{"));

        String res = call(P + "/api/reserve?diet=vegetarian&noBeef=true&noPork=true&allergies=&custom=&likes=&severe=false&spice=mild&mealId=thali&seat=18A&pid=priya.k@demo", true);
        check("passenger reserves Veg Thali over the link", res.contains("\"success\":true"));
        Thread.sleep(1000);
        String reqs = call(G + "/api/requests", false);
        check("galley (crew/catering) sees the request", reqs.contains("\"seat\":\"18A\"") && reqs.contains("Veg Thali"));

        // in-flight edit: tick peanuts (bit 0). Veg Thali has peanut chutney, so it must be swapped.
        byte[] data = um2("18A", "V", "1");
        String reply = "";
        int n = (data.length + 15) / 16;
        for (int i = 0; i < n; i++)
            reply = call(P + "/api/ble/frame?m=4242&i=" + i + "&n=" + n + "&d=" + hex(data, i * 16, Math.min(data.length, i * 16 + 16)), true);
        check("in-flight edit accepted by the server", reply.contains("\"ok\":true"));
        reqs = call(G + "/api/requests", false);
        check("galley sees CHANGED IN FLIGHT (meal swapped)", reqs.contains("\"amended\":true") && !reqs.contains("\"meal\":\"Veg Thali\""));
        String pp = call(P + "/api/passport?id=priya.k@demo", false);
        check("passenger passport updated over the link (v2+)", !pp.contains("\"version\":1,") && !pp.contains("\"version\":1}"));

        String st = call("http://localhost:3002/status", false);
        check("hub status shows the traffic (" + hub.tunnel().requests.get() + " messages, " + hub.tunnel().replays.get() + " replays)", hub.tunnel().requests.get() >= 5 && st.contains("\"linked\":true"));
        check("galley page + passenger page are served", call(G + "/galley.html", false).contains("Crew") && call(P + "/index.html", false).contains("Bluetooth"));

        System.out.println(failures.get() == 0 ? "\nALL PASSED" : "\nSOME FAILED");
        System.exit(failures.get() == 0 ? 0 : 1);
    }

    /** The message format on its own: compression, CRC, frames, shuffled/duplicated frames, damage. */
    static void unitChecks() {
        Map<String, Object> msg = Map.of("m", "GET", "p", "/api/meals?x=" + "ü\"\\\n".repeat(30));
        byte[] blob = Wire.packBlob(msg);
        check("blob round trip (JSON + zlib + CRC)", Wire.unpackBlob(blob).equals(msg));
        List<byte[]> frames = new ArrayList<>(Wire.splitFrames(77, blob, 20));
        java.util.Collections.shuffle(frames, new Random(1));
        frames.add(frames.get(0));                                  // a duplicate
        Wire.Assembler asm = new Wire.Assembler();
        byte[] done = null;
        for (byte[] f : frames) { Wire.Added a = asm.add(f); if (a.blob != null) done = a.blob; }
        check("frames in any order, with duplicates, rebuild the message", done != null && java.util.Arrays.equals(done, blob));
        Wire.Assembler asm2 = new Wire.Assembler();
        List<byte[]> fs = Wire.splitFrames(5, blob, 20);
        for (int i = 0; i < fs.size(); i++) if (i != 1 && i != 3) asm2.add(fs.get(i));
        check("missing frame numbers are reported", asm2.missing(5).equals(List.of(1, 3)));
        byte[] bad = blob.clone();
        bad[2] ^= 0x55;
        boolean caught = false;
        try { Wire.unpackBlob(bad); } catch (IllegalArgumentException e) { caught = true; }
        check("a damaged message is rejected by the CRC", caught);
    }
}
